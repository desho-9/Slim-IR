mkdir -p build && cd build
cmake -S .. -DDISABLE_IGNORE_EFFECT=ON -B .
sudo make install                                                                                     


