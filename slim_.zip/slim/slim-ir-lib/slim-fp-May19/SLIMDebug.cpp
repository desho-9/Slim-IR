#include "SLIMDebug.h"

namespace slim {
unsigned int DEBUG_LEVEL = 0;
}

