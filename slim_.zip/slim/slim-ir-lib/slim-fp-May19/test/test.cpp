// int **z, **w, *x, *y, u, v;

// struct S {
//     int *n;
// } * p, s1;

// int f(int a) {
//     a = 1;
//     return a;
// }

// int main() {
//     p = &s1;
//     p->n = &u;
//     x = p->n;
//     f(s1.n[3]);
//     return *x;
// }

#include "IR.h"
#include "llvm/IR/LLVMContext.h"
#include <catch2/catch_test_macros.hpp>
#include <llvm/IRReader/IRReader.h>
#include <llvm/Support/SourceMgr.h>
#include <memory>

unsigned int Factorial(unsigned int number) {
    return number <= 1 ? number : Factorial(number - 1) * number;
}
void f(std::unique_ptr<llvm::Module> &&module) {
    std::unique_ptr<llvm::Module> module2 = std::move(module);
}

TEST_CASE("Test isSource", "[IR]") {
    llvm::LLVMContext context;
    llvm::SMDiagnostic err;
    std::unique_ptr<llvm::Module> module =
        llvm::parseIRFile("test/testfiles/program.slim.ll", err, context);

    std::vector<std::string> notSourceVariables{
        "add_f",   "add_main", "add1_main", "i_main", "i1_main",
        "i2_main", "i3_main",  "cmp_main",  "call_main"};

    REQUIRE(module != nullptr);
    slim::IR slimIR(module);
    slimIR.dumpIR("test");
    // Check for stats
    REQUIRE(2 == slimIR.getNumberOfFunctions());
    REQUIRE(5 == slimIR.getNumberOfBasicBlocks());
    for (auto &entry : slimIR.func_bb_to_inst_id) {
        for (auto &inst_id : entry.second) {
            auto *inst = slimIR.inst_id_to_object[inst_id];
            if (inst->getResultOperand().first) {
                auto name = inst->getResultOperand().first->getName();
                // if name is in notSourceVariables, it should not be a source
                if (std::count(notSourceVariables.begin(),
                               notSourceVariables.end(), name) == 0) {
                    INFO(("Checking " + name).str());
                    REQUIRE(inst->getResultOperand().first->isSource());
                } else {
                    REQUIRE_FALSE(inst->getResultOperand().first->isSource());
                }
                // check refersToSource
                if (name == "add1_main") {
                    auto &refersTo = inst->getResultOperand()
                                         .first->getRefersToSourceValues();
                    std::vector<llvm::StringRef> refersToNames;
                    for (auto &ref : refersTo) {
                        refersToNames.push_back(ref->getName());
                    }
                    REQUIRE(refersToNames.size() == 2);
                    REQUIRE(std::count(refersToNames.begin(),
                                       refersToNames.end(),
                                       "local.0_main") == 1);
                    REQUIRE(std::count(refersToNames.begin(),
                                       refersToNames.end(), "g") == 1);
                }
            }
        }
    }
}