#include <stdio.h>
#include <stdlib.h>

struct X {
    struct X* f;
};
struct X** p;
    struct X *t, *x, *y, *z;

int main() {
    
    //p = &z;

    x = (struct X*)(malloc(sizeof(struct X)));
    y=x;
    printf("%p", (void*)x);
    y=(struct X*)(malloc(sizeof(struct X)));
    
    printf("%p", (void*)y);
    
    

    return 0;
}

