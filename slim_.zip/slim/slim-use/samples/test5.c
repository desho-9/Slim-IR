#include <stdlib.h>

int *x;

int main() {
    int i = 0,u;
    while (i <= 3) {
        if (i > 0) {
            x = malloc(sizeof(int));
        } 
		else {  
			x= &u;//malloc(sizeof(int));
        }
        i++;
    }
    return *x;
}
