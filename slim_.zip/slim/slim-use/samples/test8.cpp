#include <stdio.h>

class X {
public:
    X* f; // Assuming that 'f' is a member variable of class X
    
};
X** p;
    X *t, *x, *y, *z;

int main() {
    
   
    p = &z;

    x = new X;
    *p = x;

    // Loop to create instances of X and assign them to x->f
    for (int i = 0; i < 5; ++i) {
        y = new X;
        x->f = y;
        x = x->f;
    }

    
    //delete z;

    return 0;
}

