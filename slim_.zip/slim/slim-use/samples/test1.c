int *x, *y, u,v;
int main(){
	y = &u;
	x = y;
	if(x>0)
	{
		x=&u;
	}
	else
	{
		x=&v;
	}
	return *x;
	}
