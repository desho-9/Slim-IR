#include<stdlib.h>
int *x, *y, u,v;
int main(){
	int i=0;
	y = &u;
    while(i<=3)
    {
	    if(y>0)
	    {
		    x=malloc(sizeof(int));
	    }
	    else{
		    x=malloc(sizeof(int));
	    }
        i++;
    }
	return *x;
}
int* allocateAndReturn() {
    int *ptr = malloc(sizeof(int));
    
    return ptr;
}