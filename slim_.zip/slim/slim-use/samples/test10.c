#include <stdio.h>
#include <stdlib.h>
    int *x, *y;
    char *z;
    int c=10;

int main() {
    printf("%p", x);
    int *b,*a;
    a=&c;
    b=a;
    
    
    //int *b=&a;
    if(a!=b)
    {
    printf("%p",*a);
    }
    
    x=(malloc(sizeof(int)));
    printf("%p", x);
    printf("%p", z);
    z=(malloc(sizeof(char)));
    printf("%p", z);
    if(x!=z)
    {
    printf("%p", z);
    }

    return 0;
}

