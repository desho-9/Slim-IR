#include <stdlib.h>

struct X {
    struct X* f;
};

int main() {
    struct X* p = NULL;
    struct X* x = NULL;
    x = (struct X*)(malloc(sizeof(struct X)));
    p = x; 
    x->f = (struct X*)(malloc(sizeof(struct X))); 
 
    if(x!=x->f)
    {
    printf("p->f",x);
    printf("p->f",x->f);
    }
    return 0;
}
