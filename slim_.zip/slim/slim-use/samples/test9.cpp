#include <iostream>
#include <cstdlib> // Include the necessary header for malloc and free

class X {
public:
    X* f; // Assuming that 'f' is a member variable of class X
};
 X** p;
    X *t, *x, *y, *z;
int main() {
    

    x = (X*)(malloc(sizeof(X)));
    
    printf("Address pointed by x: %p\n", (void*)x);

    y = (X*)(malloc(sizeof(X))); 
    x->f = y;
    x = x->f;

    printf("Address pointed by y: %p\n", (void*)y);

    

    return 0;
}

