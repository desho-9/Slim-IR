#include <stdio.h>
#include <stdlib.h>
int* ptr;
int* allocateAndReturn() {
    ptr = malloc(sizeof(int));   
    return ptr;
}

int main() {
    int  *result2, result3;
    int i=0;

    int *a=malloc(sizeof(int));
    result3=*a;
   // while(i<=5)
    {
    result2=allocateAndReturn(); 
    i++;
    }

    if(*result2!=result3)
    {
        printf("",result3);
    }
    return result3;
}
