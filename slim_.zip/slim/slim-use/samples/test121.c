#include <stdio.h>
#include <stdlib.h>


int main(){
    int *x=(malloc(sizeof(int)));
    int *y;
    if(x!=y)
    {
        y=x;
    }
    return *x;
}

