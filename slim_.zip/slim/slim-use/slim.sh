#!/bin/bash
export LLVM_HOME=/usr/lib/llvm-14
CC="/usr/bin/clang-11"
OPT="/usr/lib/llvm-14/bin/opt"


ARGS=`python3 ./HandleArgs.py ${@:2}`

[ "$ARGS" ] || exit 1

if [[ ${#ARGS} -gt 200 ]]; then
    python3 ./HandleArgs.py $@
    exit 1
fi

# convert string to array
ARG=(`echo ${ARGS}`);

FOO_VAR=''


for (( Idx=0; Idx<${#ARG[@]}; Idx++ ))
do
	echo "${ARG[$Idx]}"
	FOO_VAR="${FOO_VAR}""-D"${ARG[$Idx]}';'
	
done


FOO_VAR=`echo $FOO_VAR | sed -e 's/;$//g'`
echo "$FOO_VAR"
export FOO_VAR


FILENAME=$(basename $1 .c)
#FILENAME="test100"

echo -e "${CYANB}=======================Generate LL Files using CLANG=======================${RST}"
$CC -g -S -emit-llvm -O0 -Xclang -disable-O0-optnone -fno-discard-value-names -c -o ./samples/$FILENAME.ll $1
$OPT -S -instnamer -mem2reg -mergereturn ./samples/$FILENAME.ll -o ./samples/$FILENAME.ll


