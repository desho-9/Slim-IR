#!/bin/bash
export LLVM_HOME=/usr/lib/llvm-14
CC="/usr/bin/clang-11"
OPT="/usr/lib/llvm-14/bin/opt"
DRIVER="./build/cs-ssa"


mkdir build 
cd build
make clean
cmake ..
make
cd ..

FILENAME=$(basename $1 .c)
#FILENAME="test100"

$CC -g -S -emit-llvm -O0 -Xclang -disable-O0-optnone -fno-discard-value-names -c -o ./samples/$FILENAME.ll $1
$OPT -S -instnamer -mem2reg -mergereturn ./samples/$FILENAME.ll -o ./samples/$FILENAME.ll                                                                                                   


